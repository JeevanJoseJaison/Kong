local cjson = require "cjson"
local http = require "resty.http"

local SwaggerValidator = {
    VERSION = "1.0.0",
    PRIORITY = 1000,
    name = "swagger-param-validator"
}

-- Resolve a schema by checking for and processing $ref references
function SwaggerValidator:resolve_schema(swagger_schema, schema)
    if schema["$ref"] then
        local resolved_schema, err = self:resolve_ref(swagger_schema, schema["$ref"])
        if not resolved_schema then
            return nil, "Error resolving reference: " .. err
        end
        return resolved_schema
    end
    return schema
end

function SwaggerValidator:validate_enum(value, enum_values)
    for _, enum_value in ipairs(enum_values) do
        if value == enum_value then
            return true
        end
    end
    return false, "Invalid value. Expected one of: " .. table.concat(enum_values, ", ")
end

-- Type validation helper function
function SwaggerValidator:validate_type(value, expected_type, context)
    if type(value) ~= expected_type then
        return false, "Invalid type for " .. context .. ". Expected " .. expected_type .. ", got " .. type(value)
    end
    return true
end

function SwaggerValidator:validate_parameters(parameters, swagger_parameters, swagger_schema)
    if not swagger_parameters or #swagger_parameters == 0 then
        -- No parameters to validate
        kong.log.debug("No params skipping parameter validation")
        return true
    end

    for _, param in ipairs(swagger_parameters) do

        local param_name = param.name

        local param_in = param["in"] -- e.g., "query", "path", "header"
        local param_schema = param.schema
        local is_required = param.required
        local value
        local err

        -- Get the value based on parameter location
        if param_in == "query" then
            value = kong.request.get_query()[param_name]
        elseif param_in == "path" then
            value = kong.request.get_path(param_name)
        elseif param_in == "header" then
            value = kong.request.get_header(param_name)
        end

        -- Check if required parameter is missing
        if is_required and value == nil then
            return false, "Missing required " .. param_in .. " parameter: " .. param_name
        end

        if param_schema["$ref"] then
            param_schema, err = self:resolve_schema(swagger_schema, param_schema)
            if not param_schema then
                return false, err
            end
        end
        -- kong.log.debug("param_schema: ", cjson.encode(param_schema))

        -- Enum validation
        if value ~= nil and param_schema.enum then
            local is_valid_enum, err_msg = self:validate_enum(value, param_schema.enum)
            if not is_valid_enum then
                return false, err_msg
          
            end
        end

        -- Type validation
        if value ~= nil and param_schema.type then
            local is_valid_type, err_msg = self:validate_type(value, param_schema.type,
                param_in .. " parameter '" .. param_name .. "'")
            if not is_valid_type then
                return false, err_msg
            else
                kong.log.debug("type validation successful for parameter: ", param_name)
            end
        end
    end

    return true
end

-- Load the Swagger schema file from a path or URL
function SwaggerValidator:load_swagger_schema(swagger_file_path)
    local file, err = io.open(swagger_file_path, "r")
    if not file then
        kong.log.err("Failed to open Swagger file:", err)
        return nil, "Failed to load Swagger schema"
    end

    local content = file:read("*a")
    file:close()
    return cjson.decode(content)
end

-- Helper function to resolve JSON reference ($ref)
function SwaggerValidator:resolve_ref(swagger_schema, ref)
    local parts = {}
    for part in string.gmatch(ref, "[^/]+") do
        table.insert(parts, part)
    end

    -- Traverse the Swagger schema based on the ref parts
    local resolved = swagger_schema
    for i = 2, #parts do -- Skip the first part, which is always '#'
        resolved = resolved[parts[i]]
        if not resolved then
            return nil, "Reference not found: " .. ref
        end
    end

    return resolved
end

function SwaggerValidator:match_path(swagger_path, request_path)
    local pattern = "^" .. swagger_path:gsub("{[%w_]+}", "([^/]+)") .. "$"
    return request_path:match(pattern)
end

-- Extract the schema for the current endpoint and method from the Swagger file
function SwaggerValidator:get_dto_schema(swagger_schema, request_path, request_method)
    local path_schema = swagger_schema.paths[request_path]
    if not path_schema then
        return nil, "Path not found in Swagger schema"
    end

    local method_schema = path_schema[request_method:lower()]

    -- kong.log.debug("method_schema: ", cjson.encode(method_schema))

    if not method_schema or not method_schema.requestBody then
        return nil
    end

    local schema = method_schema.requestBody.content["application/json"].schema
    if schema["$ref"] then
        return self:resolve_ref(swagger_schema, schema["$ref"])
    end
    return schema
end

function SwaggerValidator:find_matching_path(request_path, swagger_paths)
    for path_pattern in pairs(swagger_paths) do
        -- Convert Swagger path with placeholders (e.g., /path/{param}) to a Lua pattern (e.g., /path/[^/]+)
        local pattern = "^" .. path_pattern:gsub("{[^/]+}", "[^/]+") .. "$"
        if request_path:match(pattern) then
            return path_pattern
        end
    end
    return nil
end

-- Validate request body against the DTO schema
function SwaggerValidator:validate_body_schema(body, schema, swagger_schema)
    -- 1. Check if required fields are present
    -- kong.log.debug("schema_before: ",cjson.encode(schema))
    -- schema, err = self:resolve_schema(swagger_schema, schema)
    -- if not schema then
    --     return false, err
    -- end

    if schema.required then
        for _, required_field in ipairs(schema.required) do
            if body[required_field] == nil then
                return false, "Missing required field: " .. required_field
            end
        end
    end

    -- 2. Validate each field in the schema properties
    for field, props in pairs(schema.properties) do
        local value = body[field]

        -- kong.log.debug("field: ", cjson.encode(field))
        -- kong.log.debug("props: ", cjson.encode(props))

        -- Skip fields that are not required and not present in the body
        if value ~= nil then

            -- Enum validation
            if props.enum then
                local is_valid_enum, err_msg = self:validate_enum(value, props.enum)
                if not is_valid_enum then
                    return false, err_msg
                end
            end

            -- Type validation
            if props.type then
                local is_valid_type, err_msg = self:validate_type(value, props.type, "field '" .. field .. "'")
                if not is_valid_type then
                    return false, err_msg
                else
                    kong.log.debug("type validation successful for body: ",field)
                end
            end

        end
    end

    return true
end

function SwaggerValidator:access(conf)
    -- Load the Swagger schema

    local swagger_schema, err = self:load_swagger_schema(conf.swagger_file_path)
    if not swagger_schema then
        return kong.response.exit(500, {
            message = err
        })
    end

    -- kong.log.debug("swagger: ",cjson.encode(swagger_schema))

    -- Get the request path and method
    local request_path = kong.request.get_path()
    local request_method = string.lower(kong.request.get_method())

    local matched_path = self:find_matching_path(request_path, swagger_schema.paths)
    -- kong.log.debug("matching path: ", matched_path)
    if not matched_path then
        return kong.response.exit(400, {
            message = "Endpoint not defined in Swagger schema"
        })
    end

    -- Get the DTO schema for the current endpoint
    -- kong.log.debug("request_path: ", cjson.encode(request_path))
    -- kong.log.debug("request_path_after: ", cjson.encode(matched_path))

    local endpoint_schema = swagger_schema.paths[matched_path][request_method]
    if not endpoint_schema then
        return kong.response.exit(400, {
            message = "Endpoint not defined in Swagger schema"
        })
    end

    local is_valid, validation_err = self:validate_parameters(kong.request, endpoint_schema.parameters or {},
        swagger_schema)
    if not is_valid then
        return kong.response.exit(400, {
            message = validation_err
        })
    end
    -- Load the request body
    local dto_schema, err = self:get_dto_schema(swagger_schema, matched_path, request_method)

    if dto_schema ~= nill then
        local body = kong.request.get_body()
        if err then
            return kong.response.exit(400, {
                message = "Invalid request body"
            })
        end
        local is_valid, validation_err = self:validate_body_schema(body, dto_schema, swagger_schema)
        if not is_valid then
            return kong.response.exit(400, {
                message = validation_err
            })
        end
    end
    -- Validate the request body against the DTO schema

end

return SwaggerValidator
