return {
  name = "swagger-param-validator",
  fields = {
    { config = {
        type = "record",
        fields = {
          { swagger_file_path = { type = "string", required = true } }
          -- { secret = { type = "string", required = false } },
        },
      },
    },
  },
}
