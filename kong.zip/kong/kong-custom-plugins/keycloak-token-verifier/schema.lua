return {
  name = "keycloak-token-verifier",
  fields = {
    { config = {
        type = "record",
        fields = {
          { keycloak_url = { type = "string", required = true } }, 
          { cache_size = { type = "number", required = true } }, 
          { cache_ttl = { type = "number", required = true } }, 
          -- { secret = { type = "string", required = false } },
        },
      },
    },
  },
}
