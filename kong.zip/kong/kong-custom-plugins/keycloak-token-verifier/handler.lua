local http = require "resty.http"
local cjson = require "cjson"
local jwt = require "resty.jwt"
local redis = require "resty.redis"

local jwks_cache = {}
local access_order = {}
-- Define the Handler
local KeycloakTokenVerifier = {
    VERSION = "1.0.0",
    PRIORITY = 1000,
    name = "keycloak-token-verifier",
    cleanup_interval = 60 -- check for expired entries every 60 seconds
}

function KeycloakTokenVerifier:init_worker(conf)

    local cleanup_interval = self.cleanup_interval

    local ttl = (conf and conf.cache_ttl) or 300
    -- Schedule recurring task to clean expired entries
    ngx.timer.every(cleanup_interval, function()
        self:remove_expired_entries(ttl)
    end)
end

-- Optional new method, if needed for initialization
function KeycloakTokenVerifier:new()
    return setmetatable({}, {
        __index = KeycloakTokenVerifier
    })
end

function KeycloakTokenVerifier:access(conf)
    -- Fetch the token from the Authorization header
    local token = kong.request.get_header("Authorization")
    if not token or not token:match("^Bearer ") then
        return kong.response.exit(401, {
            message = "Missing or invalid authorization token"
        })
    end

    -- Remove "Bearer " prefix from the token
    token = token:sub(8)
    local decoded_token, err = jwt:load_jwt(token)

    if not decoded_token then
        -- Handle the error from loading the JWT
        return kong.response.exit(401, {
            message = "Failed to load JWT: " .. (err or "unknown error")
        })
    end

    -- Check if the jwt_obj is valid
    if type(decoded_token) ~= "table" or not decoded_token.payload then
        return kong.response.exit(401, {
            message = "Invalid token structure: No payload found"
        })
    end

    local kid = decoded_token.header.kid
    local alg = decoded_token.header.alg
    local realm_name = decoded_token.payload.realm
    local keycloak_url = conf.keycloak_url .. "/realms/" .. realm_name .. "/protocol/openid-connect/certs"
    local public_key, err = self:get_jwks_from_cache(keycloak_url, kid, conf.cache_ttl, alg, conf.cache_size)
    if not public_key then
        return kong.response.exit(500, {
            message = "Failed to retrieve public keys: " .. (err or "unknown error")
        })
    end

    local valid_token = false
    local jwt_obj = jwt:verify(public_key, token)

    if jwt_obj.verified then
        valid_token = true
        kong.log.debug("Token verification Success")
    end

    if not valid_token then
        return kong.response.exit(401, {
            message = "Invalid token signature"
        })
    end
end

function KeycloakTokenVerifier:get_jwks_from_cache(keycloak_url, kid, ttl, alg, cache_size)
    local max_cache_size = cache_size
    -- Check if the key is in cache
    local cache_entry = jwks_cache[kid]
    if cache_entry and (ngx.now() - cache_entry.timestamp < ttl) then
        kong.log.debug("Using cached key for kid: ", kid)
        -- Update access order for LRU
        self:update_access_order(kid)
        return cache_entry.public_key
    end

    kong.log.debug("Key not found in cache. Fetching key for kid: ", kid)
    local httpc = http.new()
    local res, err = httpc:request_uri(keycloak_url, {
        method = "GET"
    })

    if not res then
        kong.log.err("Failed to fetch Keycloak public keys: ", err)
        return nil, err
    end

    local jwks = cjson.decode(res.body)
    local keys = jwks.keys
    local public_key = self:get_public_key(keys, alg)

    if public_key then
        -- Cache the new key
        self:cache_public_key(kid, public_key, max_cache_size)
    end

    return public_key
end

function KeycloakTokenVerifier:update_access_order(kid)
    for i, v in ipairs(access_order) do
        if v == kid then
            table.remove(access_order, i)
            break
        end
    end
    table.insert(access_order, kid)
end

-- Remove expired entries periodically based on ttl
function KeycloakTokenVerifier:remove_expired_entries(ttl)
    local now = ngx.now()
    for kid, entry in pairs(jwks_cache) do
        if (now - entry.timestamp) >= ttl then
            jwks_cache[kid] = nil
            kong.log.debug("Removed expired cache entry for kid: ", kid)
            -- Remove kid from access_order list
            for i, v in ipairs(access_order) do
                if v == kid then
                    table.remove(access_order, i)
                    break
                end
            end
        end
    end
end

function KeycloakTokenVerifier:cache_public_key(kid, public_key, max_cache_size)
    -- Enforce cache size limit
    if #access_order >= max_cache_size then
        -- Evict the least recently used entry
        local oldest_kid = table.remove(access_order, 1)
        jwks_cache[oldest_kid] = nil
        kong.log.debug("Evicted LRU cache entry for kid: ", oldest_kid)
    end

    -- Add the new entry to the cache and access order
    jwks_cache[kid] = {
        public_key = public_key,
        timestamp = ngx.now()
    }
    table.insert(access_order, kid)
    kong.log.debug("JWKS key cached for kid: ", kid)
end

function KeycloakTokenVerifier:get_public_key(keys, alg)
    -- Find the public key in `keys` with the specified `kid`
    for _, key in pairs(keys) do
        if key.alg == alg then
            -- Construct the public key from the `x5c` field
            return "-----BEGIN CERTIFICATE-----\n" .. key.x5c[1] .. "\n-----END CERTIFICATE-----"
        end
    end
end

return KeycloakTokenVerifier
