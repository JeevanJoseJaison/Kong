local http = require "resty.http"
local cjson = require "cjson"
local jwt = require "resty.jwt"

local token_cache = {}

local KeycloakServiceTokenGenerator = {
    VERSION = "1.0.0",
    PRIORITY = 900,
    name = "keycloak-service-token",
    cleanup_interval = 10 -- run cleanup every 60 seconds
}

-- Initialize worker and set up periodic cache cleanup
function KeycloakServiceTokenGenerator:init_worker(conf)
    local cleanup_interval = self.cleanup_interval
    local ttl = (conf and conf.cache_ttl) or 300  -- default TTL of 5 minutes if not specified

    -- Schedule the cleanup task to run every minute
    ngx.timer.every(cleanup_interval, function()
        self:remove_expired_tokens(ttl)
    end)
end

function KeycloakServiceTokenGenerator:access(conf)
    local cache_key = conf.client_id
    local cached_token_data = token_cache[cache_key]
    local now = ngx.now()

    kong.log.debug("here", cjson.encode(token_cache))
    
    -- Check if cached token exists and is valid based on TTL and `exp`
    if cached_token_data then
        kong.log.debug("cache found")
        local token_expiry = cached_token_data.exp
        if now < token_expiry and (now - cached_token_data.timestamp < conf.cache_ttl) then
            -- Token is still valid; use it
            kong.service.request.set_header(conf.header_name, "Bearer " .. cached_token_data.token)
            kong.log.debug("Using cached service token for client ID: ", conf.client_id)
            return
        end
    end

    kong.log.debug("No service token found in cache for client ID: ", conf.client_id)

    -- Generate a new token if no valid cached token exists
    local token, exp, err = self:get_service_token(conf)
    if not token then
        return kong.response.exit(500, { message = "Failed to obtain service token: " .. (err or "unknown error") })
    end

    -- Cache the new token with expiration and timestamp
    token_cache[cache_key] = {
        token = token,
        exp = exp,
        timestamp = ngx.now()
    }

    kong.log.debug("Service token cached for client ID: ", conf.client_id)


    kong.service.request.set_header(conf.header_name, "Bearer " .. token)
end

function KeycloakServiceTokenGenerator:get_service_token(conf)
    local httpc = http.new()
    local keycloak_token_url = string.format("%s/realms/%s/protocol/openid-connect/token", conf.keycloak_url, conf.realm_name)
    
    local res, err = httpc:request_uri(keycloak_token_url, {
        method = "POST",
        body = ngx.encode_args({
            grant_type = "client_credentials",
            client_id = conf.client_id,
            client_secret = conf.client_secret
        }),
        headers = {
            ["Content-Type"] = "application/x-www-form-urlencoded"
        }
    })

    if not res then
        kong.log.err("Failed to fetch service token from Keycloak: ", err)
        return nil, nil, err
    end

    local response_body = cjson.decode(res.body)

    if not response_body.access_token then
        return nil, nil, "Invalid token response from Keycloak"
    end

    local token = response_body.access_token
    local decoded_token = jwt:load_jwt(token)

    if not decoded_token or not decoded_token.payload or not decoded_token.payload.exp then
        return nil, nil, "Failed to decode token or missing expiration"
    end

    local exp = decoded_token.payload.exp

    return token, exp, nil
end

-- Cleanup expired tokens from the cache based on TTL
function KeycloakServiceTokenGenerator:remove_expired_tokens(ttl)
    local now = ngx.now()
    for client_id, token_data in pairs(token_cache) do
        if (now - token_data.timestamp) >= ttl then
            token_cache[client_id] = nil
            kong.log.debug("Removed expired token for client ID: ", client_id)
        end
    end
end

return KeycloakServiceTokenGenerator
