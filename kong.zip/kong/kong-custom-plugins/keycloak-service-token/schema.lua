return {
  name = "keycloak-service-token",
  fields = {
    { config = {
        type = "record",
        fields = {
          { keycloak_url = { type = "string", required = true } }, 
          { header_name = { type = "string", required = true } }, 
          { cache_ttl = { type = "number", required = true } }, 
          { client_id = { type = "string", required = true } }, 
          { client_secret = { type = "string", required = true } }, 
          { realm_name = { type = "string", required = true } }, 


          -- { secret = { type = "string", required = false } },
        },
      },
    },
  },
}
